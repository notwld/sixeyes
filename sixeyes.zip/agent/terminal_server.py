import asyncio
import websockets
import json
import logging
import argparse
import os
import platform
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('terminal_server.log')
    ]
)
logger = logging.getLogger(__name__)

# Security settings
BLOCKED_COMMANDS = ['rm -rf', 'mkfs', 'dd', 'format', 'shutdown', 'reboot', ':(){', 'sudo rm']
MAX_OUTPUT_SIZE = 1024 * 100  # 100KB

async def execute_command(command):
    """Execute a shell command and return the output"""
    try:
        if any(blocked in command.lower() for blocked in BLOCKED_COMMANDS):
            return {'output': 'Command not allowed for security reasons', 'error': True}

        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=30)

            stdout_str = stdout.decode('utf-8', errors='replace')
            stderr_str = stderr.decode('utf-8', errors='replace')

            if len(stdout_str) > MAX_OUTPUT_SIZE:
                stdout_str = stdout_str[:MAX_OUTPUT_SIZE] + "\n... (output truncated)"
            if len(stderr_str) > MAX_OUTPUT_SIZE:
                stderr_str = stderr_str[:MAX_OUTPUT_SIZE] + "\n... (output truncated)"

            if process.returncode != 0:
                return {'output': stderr_str or 'Command failed with no output', 'error': True}
            else:
                return {'output': stdout_str or 'Command executed successfully (no output)'}

        except asyncio.TimeoutError:
            process.kill()
            return {'output': 'Command execution timed out after 30 seconds', 'error': True}

    except Exception as e:
        logger.error(f"Error executing command: {e}")
        return {'output': f'Execution error: {str(e)}', 'error': True}

async def terminal_handler(websocket, path=None):
    """Handle terminal WebSocket connection"""
    client_ip = websocket.remote_address[0]
    logger.info(f"Connection from {client_ip}")

    await websocket.send(json.dumps({
        'output': f'Connected on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\nType commands to execute.',
        'type': 'system'
    }))

    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                command = data.get('command', '').strip()

                if not command:
                    await websocket.send(json.dumps({'output': 'Enter a command', 'error': True}))
                    continue

                logger.info(f"Command from {client_ip}: {command}")
                result = await execute_command(command)
                await websocket.send(json.dumps(result))

            except json.JSONDecodeError:
                await websocket.send(json.dumps({'output': 'Invalid JSON format.', 'error': True}))
            except Exception as e:
                logger.error(f"Processing error: {e}")
                await websocket.send(json.dumps({'output': f'Error: {str(e)}', 'error': True}))
    except websockets.exceptions.ConnectionClosed:
        logger.info(f"Disconnected: {client_ip}")
    except Exception as e:
        logger.error(f"Handler error: {e}")

async def start_server(host, port):
    """Start the WebSocket server"""
    server = await websockets.serve(
        terminal_handler,
        host,
        port,
        ping_interval=30,
        ping_timeout=10
    )
    logger.info(f"Server running at ws://{host}:{port}")
    return server

def run_server():
    parser = argparse.ArgumentParser(description="WebSocket Terminal Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=3001, help="Port to bind to")
    args = parser.parse_args()

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    # Windows doesn't support signal handlers the same way, so fallback
    async def shutdown():
        logger.info("Server shutting down...")
        tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        [task.cancel() for task in tasks]
        await asyncio.gather(*tasks, return_exceptions=True)
        loop.stop()

    try:
        loop.run_until_complete(start_server(args.host, args.port))
        loop.run_forever()
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
        loop.run_until_complete(shutdown())
    except Exception as e:
        logger.error(f"Server crash: {e}")
    finally:
        loop.close()
        logger.info("Shutdown complete")

if __name__ == "__main__":
    run_server()
