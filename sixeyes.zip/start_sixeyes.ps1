Param(
    [string]$Mode = "all",
    [string]$MasterIP = "192.168.100.4",
    [int]$MasterPort = 5000,
    [string]$AgentName = "Administrator",
    [string]$MasterDir = ".\master",
    [string]$AgentDir = ".\agent",
    [string]$ClientDir = ".\client",
    [string]$LogDir = ".\logs",
    [int]$ClientPort = 5173,
    [string]$AgentMasterIP
)

Function Show-Help {
    Write-Host "SixEyes - Monitoring System"
    Write-Host "Usage: .\SixEyes.ps1 -Mode <mode> [-MasterIP <ip>] [-MasterPort <port>] [-ClientPort <port>] [-AgentName <name>] [-AgentMasterIP <ip>]"
    Write-Host ""
    Write-Host "Modes:"
    Write-Host "  master    Start only the master server"
    Write-Host "  agent     Start only the agent server"
    Write-Host "  client    Start only the client"
    Write-Host "  all       Start all components"
    Write-Host ""
}

Function Check-Dependencies {
    $deps = @("python", "pip")
    if ($Mode -eq "client" -or $Mode -eq "all") {
        $deps += "node"
        $deps += "npm"
    }
    foreach ($dep in $deps) {
        if (-not (Get-Command $dep -ErrorAction SilentlyContinue)) {
            Write-Error "$dep is required but not installed. Aborting."
            Exit 1
        }
    }
}

Function Install-Packages {
    if ($Mode -eq "master" -or $Mode -eq "agent" -or $Mode -eq "all") {
        Start-Process "pip" -ArgumentList "install flask flask-socketio flask-cors psutil requests websockets python-socketio" -NoNewWindow -Wait
    }
    if ($Mode -eq "client" -or $Mode -eq "all") {
        if (-not (Test-Path "$ClientDir\node_modules")) {
            Push-Location $ClientDir
            npm install
            Pop-Location
        }
    }
}

Function Create-LogDir {
    if (-not (Test-Path $LogDir)) {
        New-Item -ItemType Directory -Path $LogDir | Out-Null
    }
}

Function Start-Master {
    Write-Host "Starting master server..."
    $masterArgs = "main.py"
    $logPath = Join-Path $LogDir "master.log"
    Start-Process "python" -ArgumentList $masterArgs -WorkingDirectory $MasterDir -RedirectStandardOutput "$logPath.out" -RedirectStandardError "$logPath.err"
}

Function Start-Agent {
    Write-Host "Starting agent server..."
    $termArgs = "terminal_server.py --host 0.0.0.0 --port 3001"
    $termLog = Join-Path $LogDir "terminal.log"
    Start-Process "python" -ArgumentList $termArgs -WorkingDirectory $AgentDir -RedirectStandardOutput "$termLog.out" -RedirectStandardError "$termLog.err"

    $agentArgs = "main.py -i $AgentMasterIP -p $MasterPort -name $AgentName"
    $agentLog = Join-Path $LogDir "agent.log"
    Start-Process "python" -ArgumentList $agentArgs -WorkingDirectory $AgentDir -RedirectStandardOutput "$agentLog.out" -RedirectStandardError "$agentLog.err"
}

Function Start-Client {
    Write-Host "Starting client..."
    $envPath = Join-Path $ClientDir ".env"
    "PORT=$ClientPort`nREACT_APP_MASTER_URL=http://${MasterIP}:${MasterPort}" | Set-Content -Path $envPath

    $npmCommand = "npm run dev"
    Start-Process "cmd.exe" -ArgumentList "/c", $npmCommand -WorkingDirectory $ClientDir -WindowStyle Normal
}

# Validate Mode
if ($Mode -notin @("all", "master", "agent", "client")) {
    Write-Error "Invalid mode: $Mode"
    Show-Help
    Exit 1
}

# If agent mode, AgentMasterIP is required
if ($Mode -eq "agent" -and -not $AgentMasterIP) {
    Write-Error "Agent mode requires -AgentMasterIP"
    Show-Help
    Exit 1
}

# Default AgentMasterIP in "all" mode
if ($Mode -eq "all" -and -not $AgentMasterIP) {
    $AgentMasterIP = "127.0.0.1"
}

Write-Host "==== SixEyes Startup ===="
Write-Host "Mode: $Mode"

Check-Dependencies
Install-Packages
Create-LogDir

if ($Mode -eq "master" -or $Mode -eq "all") {
    Start-Master
}
if ($Mode -eq "agent" -or $Mode -eq "all") {
    Start-Agent
}
if ($Mode -eq "client" -or $Mode -eq "all") {
    Start-Client
}

Write-Host "All requested services started!"